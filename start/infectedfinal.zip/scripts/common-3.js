// This function is called upon RestAPI button click
function getDataFromRest(input1, input2){
	var result = "The inputs received were:- <br> " ;
	result += input1+"<br>";
	result += input2+"<br>";
	result += " I am the output of the rest API<br>";
	var restResultElt = document.getElementById("restResultContainer");
	restResultElt.innerHTML = result;
	
}